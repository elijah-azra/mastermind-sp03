[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/iVy9vMH8)
# Auteur
Naam:

Studentnummer:

# Installatie
Als er nog geen omgeving genaamd s2-ai is, creeer deze dan door in Anaconda Prompt naar de directory van dit project te 
gaan en daar te typen: ```conda env create -f S2_AI_conda.yaml```

# Interpreter instellen in Pycharm, er zijn twee wegen
1. Ga naar File -> Settings -> Project: <ProjectName> -> Project Interpreter -> Dan: of
  a. Kies S2-AI in het dropdown menu
  b. Add Interpreter -> Add Local Interpreter -> Conda Environment -> Use Existing Environment -> S2-AI in dropdown menu
2. Klik rechtsonder in de GUI waar je "Python" ziet staan. (Dit werkt in de huidige versie van Pycharm niet op elk systeem)

# Interpreter instellen in VSCode
1. Klik rechtsonder in de GUI waar je "Python" ziet staan. Er komt middenbovenin je scherm een dropdown menu, kies daar: S2-AI
